package template

import "embed"

//go:embed "*"
var TplFs embed.FS

//go:embed idl.proto.tpl
var IDLTemplate string
