package template

type HTTP struct {
	Method string
	Path   string
}

type Method struct {
	Name     string
	Command  string // used in generator template
	Request  string
	Response string
	HTTP     HTTP
}

type Service struct {
	Name        string
	ServiceName string
	Namespace   string
	Backend     string
	Methods     []Method
}

type IDL struct {
	PkgPath string
	Project string
	Module  string
	Package string
	Service Service
}
